These patches were originally purchased from Psychotic Giraffe (Lazornoob on Youtube) in 2013. I take no credit for these patches, and only offer these as 'vaporware' as he does not appear to be selling them anymore. Should any of these sounds be used as-is or with minor modification, please credit him appropriately! 

TransistorBased 2025